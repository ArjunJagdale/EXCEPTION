/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package jdbcstudentapp;

/**
 *
 * @author arjun
 */
import java.sql.*;

public class JDBCStudentApp {
    public static void main(String[] args) {
        
        // Specify connection requirements
        String url = "jdbc:mysql://localhost:3306/school";
        String user = "root";
        String pass = "arjun";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(url, user, pass);
            System.out.println("Connected to the Database!");

            // Insert a student
            PreparedStatement ps = conn.prepareStatement("INSERT INTO students (name, marks) VALUES (?, ?)");
            ps.setString(1, "Alice");
            ps.setInt(2, 85);
            ps.executeUpdate();
            System.out.println("Inserted Alice!");

            // Retrieve and print students
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM students");
            while (rs.next()) {
                System.out.println(rs.getInt("id") + " | " + rs.getString("name") + " | " + rs.getInt("marks"));
            }

            // Close all
            rs.close();
            ps.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
