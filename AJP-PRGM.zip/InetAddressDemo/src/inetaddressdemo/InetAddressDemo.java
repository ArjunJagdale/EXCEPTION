/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package inetaddressdemo;
import java.net.InetAddress;
/**
 *
 * @author arjun
 */
public class InetAddressDemo {

    public static void main(String[] args) throws Exception {
        InetAddress address = InetAddress.getLocalHost();
        System.out.println("Local Host Name: " + address.getHostName());
        System.out.println("Local Host Address: " + address.getHostAddress());
    }
}