package awtmenubarexample;

import java.awt.*;
import java.awt.event.*;

public class AWTMenuBarExample extends Frame {

    public AWTMenuBarExample() {
        // Set the frame title
        setTitle("AWT MenuBar Example");

        // Create the menu bar
        MenuBar menuBar = new MenuBar();

        // Create File menu
        Menu fileMenu = new Menu("File");
        MenuItem newItem = new MenuItem("New");
        MenuItem openItem = new MenuItem("Open");

        // Add submenu items to File
        fileMenu.add(newItem);
        fileMenu.add(openItem);

        // Create Edit menu
        Menu editMenu = new Menu("Edit");

        // Create View menu
        Menu viewMenu = new Menu("View");

        // Add menus to menu bar
        menuBar.add(fileMenu);
        menuBar.add(editMenu);
        menuBar.add(viewMenu);

        // Set the menu bar on the frame
        setMenuBar(menuBar);

        // Add window listener to close the window
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                dispose();
            }
        });

        // Set frame size and make it visible
        setSize(400, 300);
        setVisible(true);
    }

    public static void main(String[] args) {
        new AWTMenuBarExample();
    }
}
