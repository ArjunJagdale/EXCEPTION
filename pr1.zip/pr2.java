import java.applet.Applet;
import java.awt.Graphics;
import java.awt.Font;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.Frame;

/*
<applet code="pr2" width=400 height=200></applet>
*/

public class pr2 extends Applet implements MouseListener {
    String message = "Press any key or click the mouse";
    int x = 10, y = 50;
    Frame frame; // A frame to show when the mouse enters the applet area

    public void init() {
        addMouseListener(this);  // Register mouse listener
        setFocusable(true);     // Ensure the applet can receive key events
        requestFocusInWindow(); // Request focus to ensure key events are captured
        
        // Create the Frame but keep it hidden initially
        frame = new Frame("New Frame");
        frame.setSize(300, 200);  // Set the size of the frame
    }

    // MouseListener methods
    public void mouseClicked(MouseEvent e) {
        message = "Mouse Clicked at (" + e.getX() + ", " + e.getY() + ")";
        repaint(); // Repaint the applet to update the message
    }

    public void mouseEntered(MouseEvent e) {
        message = "Mouse Entered the applet area";
        repaint(); // Repaint the applet to update the message
        frame.setVisible(true);  // Make the frame visible when mouse enters
    }

    public void mouseExited(MouseEvent e) {
        message = "Mouse Exited the applet area";
        repaint(); // Repaint the applet to update the message
        frame.setVisible(false); // Hide the frame when mouse exits
    }

    // Unused MouseListener methods
    public void mousePressed(MouseEvent e) {}
    public void mouseReleased(MouseEvent e) {}

    public void paint(Graphics g) {
        // Set a larger font for the text
        Font largeFont = new Font("Arial", Font.PLAIN, 24);
        g.setFont(largeFont);  // Apply the font to the graphics context
        g.drawString(message, x, y); // Draw the message on the applet window
    }
}
