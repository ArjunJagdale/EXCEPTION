import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.FlowLayout;

public class pr3 {
    public static void main(String[] args) {
        JFrame mainFrame = new JFrame("Student Examination Marks Entry");
        mainFrame.setSize(400, 300);
        mainFrame.setLayout(new FlowLayout());
        mainFrame.setVisible(true);

        JLabel nameLabel = new JLabel("Student Name:");
        JTextField nameField = new JTextField(20);

        JLabel mathLabel = new JLabel("Math Marks:");
        JTextField mathField = new JTextField(5);

        JLabel scienceLabel = new JLabel("Science Marks:");
        JTextField scienceField = new JTextField(5);

        JLabel englishLabel = new JLabel("English Marks:");
        JTextField englishField = new JTextField(5);

        JButton submitButton = new JButton("Submit");

        mainFrame.add(nameLabel);
        mainFrame.add(nameField);
        mainFrame.add(mathLabel);
        mainFrame.add(mathField);
        mainFrame.add(scienceLabel);
        mainFrame.add(scienceField);
        mainFrame.add(englishLabel);
        mainFrame.add(englishField);
        mainFrame.add(submitButton);

        submitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                int mathMarks = Integer.parseInt(mathField.getText());
                int scienceMarks = Integer.parseInt(scienceField.getText());
                int englishMarks = Integer.parseInt(englishField.getText());

                int totalMarks = mathMarks + scienceMarks + englishMarks;
                double percentage = (totalMarks / 300.0) * 100;
                String result = (percentage >= 50) ? "Pass" : "Fail";

                JFrame resultFrame = new JFrame("Examination Result");
                resultFrame.setSize(300, 200);
                resultFrame.setLayout(new FlowLayout());

                resultFrame.add(new JLabel("Result for: " + name));
                resultFrame.add(new JLabel("Total Marks: " + totalMarks));
                resultFrame.add(new JLabel("Percentage: " + percentage));
                resultFrame.add(new JLabel("Result: " + result));

                resultFrame.setVisible(true);
            }
        });

    }
}
