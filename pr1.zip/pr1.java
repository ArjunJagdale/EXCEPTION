import java.applet.Applet;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/*
<applet code="pr1" width=400 height=200></applet>
*/

public class pr1 extends Applet implements KeyListener {
    String message = "Press any key";
    int x = 10, y = 50;

    public void init() {
        addKeyListener(this);  // Register key listener
        setFocusable(true);     // Ensure the applet can receive key events
        // requestFocusInWindow(); // Request focus to ensure key events are captured
    }

    public void keyPressed(KeyEvent e) {
        message = "Key Pressed: " + e.getKeyChar();
        repaint(); // Repaint the applet to update the message
    }

    public void keyReleased(KeyEvent e) {
        message = "Key Released: " + e.getKeyChar();
        repaint(); // Repaint the applet to update the message
    }

    public void keyTyped(KeyEvent e) {
        message = "Key Typed: " + e.getKeyChar();
        repaint(); // Repaint the applet to update the message
    }

    public void paint(Graphics g) {
        // Set a larger font for the text
        Font largeFont = new Font("Arial", Font.PLAIN, 24);
        g.setFont(largeFont);  // Apply the font to the graphics context
        g.drawString(message, x, y); // Draw the message on the applet window
    }
}
